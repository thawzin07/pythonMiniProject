import RPi.GPIO as GPIO
from tkinter import *

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(24,GPIO.OUT)

top=Tk()

on_button_img=PhotoImage(file="on_button.gif")
off_button_img=PhotoImage(file="off_button.gif")

button_state=False

def toggle_button_and_LED():
    global button_state
    if button_state==False:
        button_state=True #button is pressed
        B.config(image=off_button_img)
        GPIO.output(24,1) #turn LED on
    else:
        button_state=False #button is released
        B.config(image=on_button_img)
        GPIO.output(24,0) #turn LED off


B=Button(top,image=on_button_img,command=toggle_button_and_LED)

B.pack()
top.mainloop()

import RPi.GPIO as GPIO
from tkinter import *
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(22,GPIO.IN)

top=Tk()

LED_off_img=PhotoImage(file="LED_off.gif")
LED_on_img=PhotoImage(file="LED_on.gif")

def read_Button_write_LED():
    if GPIO.input(22): #button is pressed
        print("Button is pressed...")
        C.itemconfig(LED_img,image=LED_on_img) #turn LED on
    else: #button is released
        print("Button is released...")
        C.itemconfig(LED_img,image=LED_off_img) #turn LED off
    top.after(500,read_Button_write_LED) #schedule the function read... to execute
                                            #after 500 ms

C=Canvas(top,width=64,height=128)
LED_img=C.create_image(0,0,image=LED_off_img,anchor=NW)

C.pack()
top.after(0,read_Button_write_LED) #schedule the function read... to execute immediately
top.mainloop()

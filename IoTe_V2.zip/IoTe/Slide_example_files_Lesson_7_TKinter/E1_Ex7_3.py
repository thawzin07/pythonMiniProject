import spidev
from time import sleep
from tkinter import *
from math import *

my_spi=spidev.SpiDev()
my_spi.open(0,0)

top=Tk()

gauge_img=PhotoImage(file="gauge.gif")

lowest=0
highest=100
val=0

start_x=128
start_y=145
leng=100

def read_POT_write_gauge():
    my_spi.max_speed_hz=1350000
    r=my_spi.xfer2([1,8+1<<4,0]) #read ADC ch 1
    POT_val=((r[1]&3)<<8)+r[2]
    print('POT_val: ',POT_val) #debug print

    val=int(POT_val*100/1023) #scale 0-1023 to 0-100
    
    angle=pi*(val-lowest)/(highest-lowest)
    end_x=start_x-leng*cos(angle)
    end_y=start_y-leng*sin(angle)

    C.delete("all") #delete everything on canvas to redraw
    C.create_image(0,0,image=gauge_img,anchor=NW)
    C.create_line(start_x,start_y,end_x,end_y,fill="black",width=5)
    C.create_text(50,start_y+10,font="Arial 10",text=lowest)
    C.create_text(216,start_y+10,font="Arial 10",text=highest)
    C.create_text(start_x,start_y+50,font="Arial 20",text=val)
    top.after(500,read_POT_write_gauge) #schedule an update 500 ms later
    

C=Canvas(top,width=256,height=256)
C.pack()
top.after(0,read_POT_write_gauge) #schedule an update immediately
top.mainloop()

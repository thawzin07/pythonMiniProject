#This very long program combines a few files used before
#i. Ex4_4 ans - which reads a physical potentiometer & plots the readings as a matplotlib graph
#ii. 'tkinter matplotlib.py' - which adds a matplotlib graph to a tkinter window
#iii. Ex7_3 ans - which allows a virtual gauge to display the reading from a physical potentiometer
#iv. Ex7_1 ans - which allows a virtual button to control a physical LED (& a virtual LED)

#Part 1 -- import all the modules needed (arranged in alphabetical order below.. so many of them!)
from math import *
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import RPi.GPIO as GPIO
import spidev
from time import sleep
from tkinter import *

#Part 2 -- set up I/O's, initialise variables, import images, declare constants
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(24,GPIO.OUT)

spi=spidev.SpiDev() #for reading ADC/potentiometer
spi.open(0,0)

count=0 #0,1,2,3...
pot_val=0 #0-1023
val=int(pot_val*100/1023) #0-100
threshold=88 #arbitrary threshold

readings=[] #will keep the last 100 "val"
entries=[] #will keep the last 100 "count"
thresholds=[] #will keep 100 of the threshold set

top=Tk() #top frame or window

gauge_img=PhotoImage(file="gauge.gif") #just add a pointer, and you will get a gauge!
LED_off_img=PhotoImage(file="LED_off.gif") #LED off image
LED_on_img=PhotoImage(file="LED_on.gif") #LED on image
turn_off_alarm_img=PhotoImage(file="turn_off_alarm.png") #Active button image, for turning off the alarm

alarm_state=False #initially alarm off

lowest=0 #gauge's lower limit
highest=100 #gauge's upper limit
start_x=128 #pointer's start x
start_y=145 #pointer's start y
leng=100 #pointer's length

#Part 3 -- this 'daemon' is to run every sec, by matplotlib's animation function
#in multitasking computer operating system, a deemon is a computer program that runs as a background process...
def update(i):
    #3.1 - use the global variables declared earlier
    global count
    global pot_val
    global val
    global threshold
    global alarm_state

    #3.2 - read the potentiometer value, scale it to 0-100
    spi.max_speed_hz=1350000
    r=spi.xfer2([1,8+1<<4,0]) #ADC ch 1
    pot_val=((r[1]&3)<<8)+r[2]
    val=int(pot_val*100/1023)

    #3.3 - if the threshold is exceeded, change the alarm state to True
    if alarm_state is False and val>threshold:
        alarm_state=True

    #3.4a - in the alarm state, turn on the physical LED, the virtual LED, and enable the virtual button
    if alarm_state is True:
        GPIO.output(24,1)
        my_LED.itemconfig(LED_img,image=LED_on_img)
        my_button.config(state=NORMAL)
    #3.4b - otherwise, turn off the physical LED, the virtual LED, and disenable the virtual button
    else:
        GPIO.output(24,0)
        my_LED.itemconfig(LED_img,image=LED_off_img)
        my_button.config(state=DISABLED)

    #3.5 - compute the pointer's angle, end x & y
    angle=pi*(val-lowest)/(highest-lowest) #measured clockwise from 9 o'clock position
    end_x=start_x-leng*cos(angle)
    end_y=start_y-leng*sin(angle)
    
    #3.6 - redraw the gauge with new reading
    my_gauge.delete("all") #delete everything on canvas
    my_gauge.create_image(0,0,image=gauge_img,anchor=NW) #add the background image
    my_gauge.create_line(start_x,start_y,end_x,end_y,fill="black",width=5) #add the pointer
    my_gauge.create_text(50,start_y+10,font="Arial 10",text=lowest) #add the lower limit
    my_gauge.create_text(216,start_y+10,font="Arial 10",text=highest) #add the upper limit
    my_gauge.create_text(start_x,start_y+50,font="Arial 20",text=val) #add the value

    #3.7 - for each list, keep the last 100 items, add new item at the back, and increment the count
    if count>99:
        readings.pop(0)
        entries.pop(0)
        thresholds.pop(0)
    readings.append(val)    
    entries.append(count)
    thresholds.append(threshold)
    count=count+1 

    #3.8 - using the updated lists, plot the readings and the threshold on the same graph
    my_graph.clear() #clear everything on graph
    my_graph.plot(entries,readings,label='readings') #plot the readings vs the entry numbers
    my_graph.plot(entries,thresholds,label='threshold') #plot the thresholds vs the entry numbers
    my_graph.set_xlabel('1-sec samples',fontsize=10) #label the x axis
    my_graph.set_ylabel('potentiometer values',fontsize=10) #label the y axis
    my_graph.set_title('MatPlotLib live graph') #give the graph a title
    my_graph.legend() #give the graph a legend

#Part 4 -- this function is to run if the virtual ('turn off alarm') button is clicked
#Note: the physical & virtual LED's will be turned off, and the virtual button disabled, in the daemon
def off_alarm():
    global alarm_state
    alarm_state=False  

#Part 5 -- add the widgets to the top frame or window
#5.1 - my canvas (i.e. matplotlib graph) at column 0, spanning over rows 0-2
my_figure=plt.figure()
my_graph=my_figure.add_subplot(1,1,1) #add graph to figure
my_canvas=FigureCanvasTkAgg(my_figure,master=top) #add figure to canvas
my_canvas.get_tk_widget().grid(row=0,column=0,rowspan=3)

#5.2 - my gauge (a canvas) at column 1, row 0
my_gauge=Canvas(top,width=256,height=256) #width & height in pixels
my_gauge.grid(row=0,column=1)

#5.3 - my LED (a canvas) at column 1, row 1 
my_LED=Canvas(top,width=64,height=128) #width & height in pixels
LED_img=my_LED.create_image(0,0,image=LED_off_img,anchor=NW)
my_LED.grid(row=1,column=1)

#5.4 - my button (a button) at column 1, row 2
my_button=Button(top,image=turn_off_alarm_img,state=DISABLED,command=off_alarm) #initially DISABLED
my_button.grid(row=2,column=1)                        #the off_alarm function will be called if the button is clicked

#Part 6 -- set up the update to run every sec
ani=animation.FuncAnimation(my_figure,update,interval=1000) #the update function will be called every sec
top.mainloop() #main event loop










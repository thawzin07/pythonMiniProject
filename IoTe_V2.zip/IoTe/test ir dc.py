import RPi.GPIO as GPIO#import RPi.GPIO module
from time import sleep

GPIO.setmode(GPIO.BCM) #choose BCM mode
GPIO.setwarnings(False)
GPIO.setup(17,GPIO.IN) #set GPIO 4 as ir sensor input

GPIO.setup(23,GPIO.OUT) #set GPIO 23 as Motor output
PWM = GPIO.PWM(23,100) #set 100Hz PWM output at GPIO 23

while (True):
    if GPIO.input(17) == 0: #if read a high at GPIO 4, moisture present
        print ('detected High moisture')
        GPIO.output(23,0)
    else: #otherwise (i.e. read a low) at GPIO 4, no moisture
        print('detected no moisture')
        GPIO.output(23,1) #output logic high/'1', motor
    sleep(1) # to limit print() frequency

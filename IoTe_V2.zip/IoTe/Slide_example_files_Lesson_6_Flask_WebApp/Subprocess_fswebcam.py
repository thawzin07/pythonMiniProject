import subprocess
from time import sleep

while(True):
    subprocess.run(["fswebcam","static/figure.jpg"])
    print("taking picture")
    sleep(1)

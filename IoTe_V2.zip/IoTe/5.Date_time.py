import time
print(time.strftime("%H:%M:%S"))
print(time.strftime("%d/%m/%Y"))
      

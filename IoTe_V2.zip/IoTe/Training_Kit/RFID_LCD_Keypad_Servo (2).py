import RPi.GPIO as GPIO
from time import sleep
from mfrc522 import SimpleMFRC522
import I2C_LCD_driver

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Keypad setup
MATRIX = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
          ['*', 0, '#']]

ROW = [6, 20, 19, 13]
COL = [12, 5, 16]

passcode = [1, 2, 3, 4]
entered_passcode = []

# RFID reader setup
reader = SimpleMFRC522()
auth = []

# LCD setup
LCD = I2C_LCD_driver.lcd()
sleep(0.5)
LCD.backlight(0)
sleep(0.5)
LCD.backlight(1)

# Servo setup
GPIO.setup(26, GPIO.OUT)
PWM = GPIO.PWM(26, 50)

def move_servo(angle):
    duty = angle / 18 + 2
    GPIO.output(26, True)
    PWM.ChangeDutyCycle(duty)
    sleep(1)
    GPIO.output(26, False)
    PWM.ChangeDutyCycle(0)

def check_passcode():
    if len(entered_passcode) == len(passcode):
        if entered_passcode == passcode:
            print("Authentication successful. Access granted.")
            LCD.lcd_display_string("Auth successful.", 1)
            LCD.lcd_display_string("Access granted.", 2)
            move_servo(180)
            sleep(2)
            move_servo(0)
            LCD.lcd_clear()
            LCD.backlight(0)
        else:
            print("Authentication failed. Access denied.")
            LCD.lcd_display_string("Auth failed.", 1)
            LCD.lcd_display_string("Access denied.", 2)
            sleep(2)
            LCD.lcd_clear()
            LCD.backlight(0)
        entered_passcode.clear()

while True:
    # Keypad input
    for i in range(3):
        GPIO.setup(COL[i], GPIO.OUT)
        GPIO.output(COL[i], 1)
    for j in range(4):
        GPIO.setup(ROW[j], GPIO.IN, pull_up_down=GPIO.PUD_UP)

    # RFID input
    #id = None

    print("Please enter the passcode or scan an RFID tag.")
    while all(GPIO.input(row) for row in ROW):
        for x in range(3):
            GPIO.output(COL[x], 0)
            for y in range(4):
                if GPIO.input(ROW[y]) == 0:
                    entered_passcode.append(MATRIX[y][x])
                    LCD.lcd_display_string('*', 1, len(entered_passcode))
                    while GPIO.input(ROW[y]) == 0:
                        sleep(0.1)
            GPIO.output(COL[x], 1)

        try:
            id = reader.read_id()
        except:
            pass
#id is None and 

    # Keypad input handling
    check_passcode()

    # RFID input handling
    """if id is not None:
        id = str(id)
        with open("authlist.txt", "r") as f:
            auth = f.read().splitlines()
        if id in auth:
            pos = auth.index(id)
            print("Card with UID", id, "found in database entry #", pos, "; access granted")
            LCD.lcd_display_string("Card found.", 1)
            LCD.lcd_display_string("Access granted.", 2)
            move_servo(180)
            sleep(10)
            move_servo(0)
            LCD.lcd_clear()
            LCD.backlight(0)
        else:
            print("Card with UID", id, "not found in database; access denied")
            LCD.lcd_display_string("Card not found.", 1)
            LCD.lcd_display_string("Access denied.", 2)
            sleep(2)
            LCD.lcd_clear()
            LCD.backlight(0)"""

    sleep(0.1)

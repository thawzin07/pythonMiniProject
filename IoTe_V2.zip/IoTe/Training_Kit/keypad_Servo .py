import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

MATRIX = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
          ['*', 0, '#']]

ROW = [6, 20, 19, 13]
COL = [12, 5, 16]

passcode = [1, 2, 3, 4]
alarm = False

GPIO.setup(26, GPIO.OUT)
PWM = GPIO.PWM(26, 50)
GPIO.setup(24,GPIO.OUT)

for i in range(3):
    GPIO.setup(COL[i], GPIO.OUT)
    GPIO.output(COL[i], 1)

for j in range(4):
    GPIO.setup(ROW[j], GPIO.IN, pull_up_down=GPIO.PUD_UP)

entered_passcode = []

while True:
    for x in range(4):
        for i in range(3):
            GPIO.output(COL[i], 0)
            for j in range(4):
                if GPIO.input(ROW[j]) == 0:
                    entered_passcode.append(MATRIX[j][i])
                    print(entered_passcode)
                    while GPIO.input(ROW[j]) == 0:
                        sleep(0.1)
            GPIO.output(COL[i], 1)

    if len(entered_passcode) == len(passcode):
        if entered_passcode == passcode:
            print("Authentication successful. Access granted.")
            PWM.start(3)  # Move servo to 180 degrees (3% duty cycle)
            sleep(2)  # Wait for 2 seconds
            PWM.start(12)  # Move servo to 0 degrees (12% duty cycle)
            sleep(2)  # Wait for 2 seconds
        else:
            print("Authentication failed. Access denied.")
            alarm = True
        entered_passcode = []

    if alarm == True:
        for k in range(10):
            GPIO.output(24,1) #output logic high/'1'
            sleep(1) #delay 1 second
            GPIO.output(24,0) #output logic low/'0'
            sleep(1) #delay 1 second
    alarm = False
        

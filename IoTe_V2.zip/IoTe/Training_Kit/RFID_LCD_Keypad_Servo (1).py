import RPi.GPIO as GPIO
import I2C_LCD_driver
from time import sleep
from mfrc522 import SimpleMFRC522
import sys 

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

LCD = I2C_LCD_driver.lcd()
sleep(0.5)
LCD.backlight(0)
sleep(0.5)
LCD.backlight(1)

MATRIX = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
          ['*', 0, '#']]

ROW = [6, 20, 19, 13]
COL = [12, 5, 16]

passcode = [1, 2, 3, 4]
g = 1

GPIO.setup(26, GPIO.OUT)
PWM = GPIO.PWM(26, 50)

reader = SimpleMFRC522()
auth = []

for i in range(3):
    GPIO.setup(COL[i], GPIO.OUT)
    GPIO.output(COL[i], 1)

for j in range(4):
    GPIO.setup(ROW[j], GPIO.IN, pull_up_down=GPIO.PUD_UP)

entered_passcode = []

def move_servo():
    PWM.start(3)  # Move servo to 180 degrees (3% duty cycle)
    sleep(2)  # Wait for 2 seconds
    PWM.start(12)  # Move servo to 0 degrees (12% duty cycle)
    sleep(2)  # Wait for 2 seconds

def check_auth(id):
    if id in auth:
        pos = auth.index(id)
        print("Card with UID", id, "found in database entry #", pos, "; access granted")
        return True
    else:
        print("Card with UID", id, "not found in database; access denied")
        return False

while True:
    print("Hold card near the reader to check if it is in the database")
    id = reader.read_id()
    id = str(id)
    f = open("authlist.txt", "r+")
    if f.mode == "r+":
        auth = f.read().split('\n')
    else:
        continue
    if check_auth(id):
        print("RFID authentication successful. Access granted.")
        LCD.lcd_display_string("Auth successful.", 1)
        LCD.lcd_display_string("Access granted.", 2)
        move_servo()
    else:
        print("RFID authentication failed. Access denied.")
        LCD.lcd_display_string("Auth failed.", 1)
        LCD.lcd_display_string("Access denied.", 2)
    sleep(2)
        

    for x in range(4):
        for i in range(3):
            GPIO.output(COL[i], 0)
            for j in range(4):
                if GPIO.input(ROW[j]) == 0:
                    entered_passcode.append(MATRIX[j][i])
                    LCD.lcd_display_string('*', 1, len(entered_passcode))
                    while GPIO.input(ROW[j]) == 0:
                        sleep(0.1)
            GPIO.output(COL[i], 1)

    if len(entered_passcode) == len(passcode):
        if entered_passcode == passcode:
            print("Keypad authentication successful. Access granted.")
            LCD.lcd_display_string("Auth successful.", 1)
            LCD.lcd_display_string("Access granted.", 2)
            move_servo()
            entered_passcode = []
            LCD.lcd_clear()
            LCD.backlight(0)
            continue
        else:
            print("Failed")
    g = 1
    print("1")
        


        

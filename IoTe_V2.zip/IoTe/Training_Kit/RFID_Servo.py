import RPi.GPIO as GPIO
from time import sleep
import sys
from mfrc522 import SimpleMFRC522

GPIO.setmode(GPIO.BCM)  # choose BCM mode
GPIO.setwarnings(False)
GPIO.setup(26, GPIO.OUT)  # set GPIO 26 as output

reader = SimpleMFRC522()
auth = []

PWM = GPIO.PWM(26, 50)  # set 50Hz PWM output at GPIO26
PWM.start(0)  # start PWM with 0% duty cycle

def move_servo(angle):
    duty = angle / 18 + 2
    GPIO.output(26, True)
    PWM.ChangeDutyCycle(duty)
    sleep(1)
    GPIO.output(26, False)
    PWM.ChangeDutyCycle(0)

while True:
    print("Hold card near the reader to check if it is in the database")
    id = reader.read_id()
    id = str(id)
    f = open("authlist.txt", "r+")
    if f.mode == "r+":
        auth = f.read()
    if id in auth:
        number = auth.split('\n')
        pos = number.index(id)
        print("Card with UID", id, "found in database entry #", pos, "; access granted")
        move_servo(180)
        sleep(10)
        move_servo(0)
    else:
        print("Card with UID", id, "not found in database; access denied")
    sleep(2)
import RPi.GPIO as GPIO
import I2C_LCD_driver 
from time import sleep
from mfrc522 import SimpleMFRC522

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

MATRIX = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
          ['*', 0, '#']]  # layout of keys on keypad

ROW = [6, 20, 19, 13]  # row pins
COL = [12, 5, 16]  # column pins

passcode = [1, 2, 3, 4]  # Example passcode for authentication

GPIO.setup(26, GPIO.OUT)  # set GPIO 26 as output for servo
PWM = GPIO.PWM(26, 50)  # set 50Hz PWM output at GPIO 26
PWM.start(0)  # start PWM with 0% duty cycle

reader = SimpleMFRC522()

LCD = I2C_LCD_driver.lcd() #instantiate an lcd object, call it LCD

auth = []

def move_servo(angle):
    duty = angle / 18 + 2
    GPIO.output(26, True)
    PWM.ChangeDutyCycle(duty)
    sleep(1)
    GPIO.output(26, False)
    PWM.ChangeDutyCycle(0)

def check_passcode(entered_passcode):
    if len(entered_passcode) == len(passcode):
        if entered_passcode == passcode:
            LCD.backlight(1) #turn backlight on 
            LCD.lcd_display_string("Authentication successful. Access granted.", 1) #write on line 1
            sleep(2) #wait 2 sec
            LCD.lcd_clear() #clear the display
            return True
        else:
            LCD.lcd_display_string("Authentication failed. Access denied.", 1) #write on line 1
            sleep(2) #wait 2 sec
            LCD.lcd_clear() #clear the display

            return False
    return False

def check_rfid(id):
    id = str(id)
    with open("authlist.txt", "r+") as f:
        auth = f.read()
        if id in auth:
            number = auth.split('\n')
            pos = number.index(id)
            LCD.backlight(1) #turn backlight on 
            LCD.lcd_display_string("Card with UID", id, "found in database entry #", pos, "; Access granted.", 1) #write on line 1
            sleep(2) #wait 2 sec
            LCD.lcd_clear() #clear the display
            return True
        else:
            print("RFID: Card with UID", id, "not found in database; access denied")
            LCD.lcd_display_string("Card with UID", id, "not found in database; Access denied.", 1) #write on line 1
            sleep(2) #wait 2 sec
            LCD.lcd_clear() #clear the display
            return False

def reset_entered_passcode():
    entered_passcode = []

# Set column pins as outputs, and write default value of 1 to each
for i in range(3):
    GPIO.setup(COL[i], GPIO.OUT)
    GPIO.output(COL[i], 1)

# Set row pins as inputs, with pull up
for j in range(4):
    GPIO.setup(ROW[j], GPIO.IN, pull_up_down=GPIO.PUD_UP)

entered_passcode = []

# Scan keypad and authenticate
while True:
    for x in range(4):
        for i in range(3):  # Loop through all columns
            GPIO.output(COL[i], 0)  # Pull one column pin low
            for j in range(4):  # Check which row pin becomes low
                if GPIO.input(ROW[j]) == 0:  # If a key is pressed
                    entered_passcode.append(MATRIX[j][i])  # Store the entered digit
                    while GPIO.input(ROW[j]) == 0:  # Debounce
                        sleep(0.1)
            GPIO.output(COL[i], 1)  # Write back default value of 1

    if check_passcode(entered_passcode) or check_rfid(reader.read_id()):
        move_servo(180)
        sleep(10)
        move_servo(0)
        reset_entered_passcode()

    sleep(0.1)